"""
YOLOv11 人脸表情检测后端服务
支持实时视频流处理和WebSocket通信
"""

import cv2
import numpy as np
import base64
import json
import asyncio
from fastapi import FastAPI, WebSocket, File, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from ultralytics import YOLO
import logging
from datetime import datetime
import torch
import uvicorn

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# 初始化FastAPI应用
app = FastAPI(title="Emotion Detection Service", version="1.0.0")

# 添加CORS中间件 - 允许所有来源
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# 表情标签映射
EMOTION_LABELS = {
    0: "angry",      # 生气
    1: "disgust",    # 厌恶
    2: "fear",       # 恐惧
    3: "happy",      # 开心
    4: "neutral",    # 平静
    5: "sad",        # 悲伤
    6: "surprise",   # 惊讶
}

# 简化的表情映射（5种基本表情）
EMOTION_MAP = {
    "angry": "angry",
    "disgust": "angry",
    "fear": "fear",
    "happy": "happy",
    "neutral": "neutral",
    "sad": "sad",
    "surprise": "fear",
}

class EmotionDetector:
    def __init__(self):
        """初始化表情检测器"""
        self.model = None
        self.device = "cuda" if torch.cuda.is_available() else "cpu"
        self.load_model()
    
    def load_model(self):
        """加载YOLOv11模型"""
        try:
            logger.info(f"正在加载YOLOv11模型... (设备: {self.device})")
            # 使用YOLOv11nano进行快速推理
            self.model = YOLO("yolov11n.pt")
            self.model.to(self.device)
            logger.info("YOLOv11模型加载成功")
        except Exception as e:
            logger.error(f"模型加载失败: {e}")
            self.model = None
    
    def detect_faces(self, frame):
        """
        检测图像中的人脸
        
        Args:
            frame: OpenCV图像帧
            
        Returns:
            人脸检测结果列表
        """
        if self.model is None:
            return []
        
        try:
            # 运行YOLOv11推理
            results = self.model(frame, verbose=False)
            
            detections = []
            for result in results:
                boxes = result.boxes
                for box in boxes:
                    # 获取边界框坐标
                    x1, y1, x2, y2 = box.xyxy[0].cpu().numpy()
                    confidence = box.conf[0].cpu().item()
                    
                    # 只保留人脸检测（类别0通常是person）
                    if box.cls[0].cpu().item() == 0:  # person class
                        detections.append({
                            "x1": int(x1),
                            "y1": int(y1),
                            "x2": int(x2),
                            "y2": int(y2),
                            "confidence": float(confidence),
                            "width": int(x2 - x1),
                            "height": int(y2 - y1),
                        })
            
            return detections
        except Exception as e:
            logger.error(f"人脸检测失败: {e}")
            return []
    
    def predict_emotion(self, face_roi):
        """
        预测人脸的表情
        
        Args:
            face_roi: 人脸ROI图像
            
        Returns:
            表情标签和置信度
        """
        try:
            # 这里使用简单的启发式方法来预测表情
            # 在实际应用中，应该使用专门的表情识别模型
            
            # 将图像转换为灰度
            gray = cv2.cvtColor(face_roi, cv2.COLOR_BGR2GRAY)
            
            # 计算图像特征
            # 使用Laplacian算子检测边缘（表情变化）
            laplacian = cv2.Laplacian(gray, cv2.CV_64F)
            variance = laplacian.var()
            
            # 计算直方图
            hist = cv2.calcHist([gray], [0], None, [256], [0, 256])
            
            # 基于特征进行简单的表情分类
            # 这是一个简化版本，实际应该使用训练好的模型
            if variance > 500:
                emotion = "happy"  # 高方差表示表情变化大
                confidence = min(0.95, variance / 1000)
            elif variance > 300:
                emotion = "sad"
                confidence = min(0.85, variance / 1000)
            elif variance > 100:
                emotion = "angry"
                confidence = min(0.75, variance / 1000)
            else:
                emotion = "neutral"
                confidence = 0.7
            
            return emotion, float(confidence)
        except Exception as e:
            logger.error(f"表情预测失败: {e}")
            return "neutral", 0.5
    
    def process_frame(self, frame):
        """
        处理单个视频帧
        
        Args:
            frame: OpenCV图像帧
            
        Returns:
            处理后的图像和检测结果
        """
        detections = self.detect_faces(frame)
        
        results = []
        for detection in detections:
            x1, y1, x2, y2 = detection["x1"], detection["y1"], detection["x2"], detection["y2"]
            
            # 提取人脸ROI
            face_roi = frame[y1:y2, x1:x2]
            
            if face_roi.size > 0:
                # 预测表情
                emotion, confidence = self.predict_emotion(face_roi)
                
                # 映射到5种基本表情
                mapped_emotion = EMOTION_MAP.get(emotion, "neutral")
                
                results.append({
                    "emotion": mapped_emotion,
                    "confidence": confidence,
                    "box": {
                        "x1": detection["x1"],
                        "y1": detection["y1"],
                        "x2": detection["x2"],
                        "y2": detection["y2"],
                        "width": detection["width"],
                        "height": detection["height"],
                    },
                    "detection_confidence": detection["confidence"]
                })
        
        return results

# 全局检测器实例
detector = EmotionDetector()

# ============ API 端点 ============

@app.get("/health")
async def health_check():
    """健康检查端点"""
    return {
        "status": "healthy",
        "model_loaded": detector.model is not None,
        "device": detector.device,
        "timestamp": datetime.now().isoformat()
    }

@app.post("/detect")
async def detect_emotion(file: UploadFile = File(...)):
    """
    检测单个图像中的表情
    
    Args:
        file: 上传的图像文件
        
    Returns:
        检测结果JSON
    """
    try:
        # 读取上传的文件
        contents = await file.read()
        nparr = np.frombuffer(contents, np.uint8)
        frame = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
        
        if frame is None:
            return JSONResponse(
                status_code=400,
                content={"error": "无法解析图像文件"}
            )
        
        # 处理帧
        results = detector.process_frame(frame)
        
        return {
            "status": "success",
            "detections": results,
            "timestamp": datetime.now().isoformat()
        }
    except Exception as e:
        logger.error(f"检测失败: {e}")
        return JSONResponse(
            status_code=500,
            content={"error": str(e)}
        )

@app.websocket("/ws/detect")
async def websocket_detect(websocket: WebSocket):
    """
    WebSocket端点用于实时视频流处理
    
    期望客户端发送：
    {
        "type": "frame",
        "data": "base64编码的图像数据"
    }
    
    返回：
    {
        "type": "detection",
        "detections": [...],
        "timestamp": "..."
    }
    """
    await websocket.accept()
    logger.info("WebSocket客户端已连接")
    
    try:
        while True:
            # 接收客户端消息
            data = await websocket.receive_text()
            message = json.loads(data)
            
            if message.get("type") == "frame":
                try:
                    # 解码base64图像
                    frame_data = base64.b64decode(message.get("data", ""))
                    nparr = np.frombuffer(frame_data, np.uint8)
                    frame = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
                    
                    if frame is None:
                        continue
                    
                    # 处理帧
                    results = detector.process_frame(frame)
                    
                    # 发送检测结果
                    response = {
                        "type": "detection",
                        "detections": results,
                        "timestamp": datetime.now().isoformat()
                    }
                    
                    await websocket.send_json(response)
                    
                except Exception as e:
                    logger.error(f"处理帧失败: {e}")
                    await websocket.send_json({
                        "type": "error",
                        "message": str(e)
                    })
    
    except Exception as e:
        logger.error(f"WebSocket错误: {e}")
    finally:
        logger.info("WebSocket客户端已断开连接")

@app.get("/")
async def root():
    """根路由"""
    return {
        "name": "Emotion Detection Service",
        "version": "1.0.0",
        "endpoints": {
            "health": "/health",
            "detect": "/detect (POST)",
            "websocket": "/ws/detect (WebSocket)"
        }
    }

if __name__ == "__main__":
    # 启动服务器
    # 注意：在生产环境中应该使用Gunicorn或其他ASGI服务器
    uvicorn.run(
        app,
        host="0.0.0.0",
        port=5000,
        log_level="info"
    )
