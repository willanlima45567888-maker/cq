# YOLOv11 情感检测后端服务

这是一个基于YOLOv11的实时人脸表情检测后端服务，提供HTTP REST API和WebSocket实时流处理。

## 功能特性

- ✅ 实时人脸检测（YOLOv11）
- ✅ 表情识别（5种基本表情）
- ✅ HTTP REST API接口
- ✅ WebSocket实时流处理
- ✅ GPU加速支持
- ✅ 跨平台兼容

## 系统要求

- Python 3.8+
- CUDA 11.0+（可选，用于GPU加速）
- 4GB+ RAM
- 2GB+ 磁盘空间（用于模型文件）

## 安装

### 1. 安装系统依赖

**Ubuntu/Debian:**
```bash
sudo apt-get update
sudo apt-get install -y python3-dev python3-pip libopencv-dev
```

**macOS:**
```bash
brew install python3 opencv
```

**Windows:**
- 下载并安装 Python 3.8+
- 下载并安装 Visual C++ Build Tools

### 2. 安装Python依赖

```bash
# 进入后端目录
cd python-backend

# 创建虚拟环境
python3 -m venv venv

# 激活虚拟环境
# Linux/macOS:
source venv/bin/activate
# Windows:
venv\Scripts\activate

# 安装依赖
pip install -r requirements.txt
```

### 3. 启动服务

```bash
# 使用启动脚本
./start.sh

# 或直接运行
python3 app.py
```

服务将在 `http://localhost:5000` 启动。

## API文档

### 1. 健康检查

**请求:**
```
GET /health
```

**响应:**
```json
{
  "status": "healthy",
  "model_loaded": true,
  "device": "cuda",
  "timestamp": "2024-02-03T10:00:00"
}
```

### 2. 图像检测

**请求:**
```
POST /detect
Content-Type: multipart/form-data

file: <image_file>
```

**响应:**
```json
{
  "success": true,
  "detections": [
    {
      "emotion": "happy",
      "confidence": 0.95,
      "box": {
        "x": 100,
        "y": 150,
        "width": 200,
        "height": 250
      }
    }
  ],
  "image": "base64_encoded_image",
  "timestamp": "2024-02-03T10:00:00"
}
```

### 3. WebSocket实时流

**连接:**
```
WS ws://localhost:5000/ws/detect
```

**发送消息格式:**
```json
{
  "image": "base64_encoded_image",
  "frame_id": 1
}
```

**接收消息格式:**
```json
{
  "frame_id": 1,
  "detections": [
    {
      "emotion": "happy",
      "confidence": 0.95,
      "box": {
        "x": 100,
        "y": 150,
        "width": 200,
        "height": 250
      }
    }
  ],
  "image": "base64_encoded_image",
  "timestamp": "2024-02-03T10:00:00"
}
```

### 4. 获取可用模型

**请求:**
```
GET /models
```

**响应:**
```json
{
  "available_models": [
    "yolov11n.pt",
    "yolov11s.pt",
    "yolov11m.pt"
  ],
  "current_model": "yolov11n.pt",
  "device": "cuda"
}
```

## 表情类型

系统支持以下5种基本表情：

| 表情 | 代码 | 说明 |
|------|------|------|
| 开心 | happy | 笑脸 |
| 悲伤 | sad | 哭脸 |
| 生气 | angry | 愤怒表情 |
| 恐惧 | fearful | 害怕表情 |
| 平静 | neutral | 中性表情 |

## 性能优化

### 1. GPU加速

如果系统有NVIDIA GPU，服务会自动使用CUDA加速：

```bash
# 检查GPU是否可用
python3 -c "import torch; print(torch.cuda.is_available())"
```

### 2. 模型选择

- **yolov11n.pt** (Nano) - 最快，适合实时处理
- **yolov11s.pt** (Small) - 平衡性能和准确率
- **yolov11m.pt** (Medium) - 最高准确率，但较慢

### 3. 图像压缩

WebSocket接口自动使用JPEG压缩（质量80）来减少传输数据量。

## 故障排除

### 问题1: 模型下载失败

**解决方案:**
```bash
# 手动下载模型
python3 -c "from ultralytics import YOLO; YOLO('yolov11n.pt')"
```

### 问题2: GPU内存不足

**解决方案:**
- 使用更小的模型（yolov11n.pt）
- 减少批处理大小
- 降低输入图像分辨率

### 问题3: 检测准确率低

**解决方案:**
- 确保光线充足
- 使用更大的模型（yolov11m.pt）
- 调整置信度阈值

## 与前端集成

### JavaScript客户端示例

```javascript
// HTTP请求示例
async function detectEmotion(imageFile) {
  const formData = new FormData();
  formData.append('file', imageFile);
  
  const response = await fetch('http://localhost:5000/detect', {
    method: 'POST',
    body: formData
  });
  
  return await response.json();
}

// WebSocket示例
const ws = new WebSocket('ws://localhost:5000/ws/detect');

ws.onopen = () => {
  // 发送视频帧
  const canvas = document.getElementById('canvas');
  canvas.toBlob(blob => {
    const reader = new FileReader();
    reader.onload = (e) => {
      const base64 = e.target.result.split(',')[1];
      ws.send(JSON.stringify({
        image: base64,
        frame_id: frameId
      }));
    };
    reader.readAsDataURL(blob);
  });
};

ws.onmessage = (event) => {
  const result = JSON.parse(event.data);
  console.log('检测结果:', result.detections);
};
```

## 部署到生产环境

### 使用Gunicorn

```bash
pip install gunicorn

# 启动多个worker进程
gunicorn -w 4 -b 0.0.0.0:5000 app:app
```

### 使用Docker

```dockerfile
FROM python:3.11-slim

WORKDIR /app

COPY requirements.txt .
RUN pip install -r requirements.txt

COPY app.py .

CMD ["python3", "app.py"]
```

构建和运行：
```bash
docker build -t emotion-detection .
docker run -p 5000:5000 emotion-detection
```

### 使用Nginx反向代理

```nginx
upstream emotion_backend {
    server localhost:5000;
}

server {
    listen 80;
    server_name api.example.com;

    location / {
        proxy_pass http://emotion_backend;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
    }

    location /ws/detect {
        proxy_pass http://emotion_backend;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
    }
}
```

## 许可证

MIT License

## 支持

如有问题，请提交Issue或联系技术支持。
