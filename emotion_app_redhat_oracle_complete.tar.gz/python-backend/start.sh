#!/bin/bash

# 情感检测后端服务启动脚本

echo "=========================================="
echo "YOLOv11 情感检测后端服务"
echo "=========================================="

# 检查Python版本
if ! command -v python3 &> /dev/null; then
    echo "❌ 未找到Python3，请先安装"
    exit 1
fi

echo "✅ Python版本: $(python3 --version)"

# 创建虚拟环境（如果不存在）
if [ ! -d "venv" ]; then
    echo "📦 创建虚拟环境..."
    python3 -m venv venv
fi

# 激活虚拟环境
echo "🔄 激活虚拟环境..."
source venv/bin/activate

# 安装依赖
echo "📥 安装依赖..."
pip install --upgrade pip
pip install -r requirements.txt

# 启动服务
echo ""
echo "🚀 启动服务..."
echo "访问地址: http://localhost:5000"
echo "API文档: http://localhost:5000/docs"
echo ""

export PYTHON_PORT=5000
python3 app.py
