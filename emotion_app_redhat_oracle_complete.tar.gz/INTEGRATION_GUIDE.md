# 完整集成部署指南

本指南说明如何将YOLOv11后端与React前端集成并部署。

## 架构概览

```
┌─────────────────────────────────────────────────────────────┐
│                    用户浏览器                                  │
│  ┌──────────────────────────────────────────────────────┐   │
│  │  React前端应用 (http://localhost:3000)              │   │
│  │  - 摄像头捕获                                        │   │
│  │  - 视频帧处理                                        │   │
│  │  - 结果展示                                          │   │
│  └──────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────┘
                          ↕ WebSocket
                    (ws://localhost:5000)
┌─────────────────────────────────────────────────────────────┐
│              Python后端服务 (localhost:5000)                 │
│  ┌──────────────────────────────────────────────────────┐   │
│  │  FastAPI + YOLOv11                                   │   │
│  │  - 人脸检测                                          │   │
│  │  - 表情识别                                          │   │
│  │  - 实时处理                                          │   │
│  └──────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────┘
```

## 快速开始

### 1. 启动Python后端

```bash
cd emotion_system_showcase/python-backend

# 安装依赖
pip install -r requirements.txt

# 启动服务
python3 app.py

# 或使用启动脚本
./start.sh
```

服务将在 `http://localhost:5000` 启动。

### 2. 配置前端

编辑 `client/src/lib/emotionDetectionClient.ts` 中的WebSocket URL：

```typescript
// 本地开发
const client = getEmotionDetectionClient("ws://localhost:5000/ws/detect");

// 生产环境
const client = getEmotionDetectionClient("wss://api.example.com/ws/detect");
```

### 3. 启动React前端

```bash
# 在项目根目录
pnpm dev

# 访问 http://localhost:3000
```

## 部署到生产环境

### 方案1：同一服务器部署

#### 步骤1：准备服务器

```bash
# Ubuntu 20.04+
sudo apt-get update
sudo apt-get install -y python3.11 python3.11-venv nodejs npm nginx

# 安装pnpm
npm install -g pnpm
```

#### 步骤2：部署Python后端

```bash
cd /opt/emotion-system/python-backend

# 创建虚拟环境
python3.11 -m venv venv
source venv/bin/activate

# 安装依赖
pip install -r requirements.txt

# 使用Gunicorn启动
pip install gunicorn
gunicorn -w 4 -b 127.0.0.1:5000 app:app
```

#### 步骤3：部署React前端

```bash
cd /opt/emotion-system

# 构建前端
pnpm install
pnpm build

# 使用Nginx提供静态文件
```

#### 步骤4：配置Nginx

创建 `/etc/nginx/sites-available/emotion-system`:

```nginx
upstream python_backend {
    server 127.0.0.1:5000;
}

server {
    listen 80;
    server_name api.example.com;
    client_max_body_size 50M;

    # 前端静态文件
    location / {
        root /opt/emotion-system/dist;
        try_files $uri $uri/ /index.html;
    }

    # 后端API
    location /api/ {
        proxy_pass http://python_backend;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }

    # WebSocket
    location /ws/ {
        proxy_pass http://python_backend;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        
        # WebSocket超时设置
        proxy_read_timeout 86400;
        proxy_send_timeout 86400;
    }
}
```

启用站点：
```bash
sudo ln -s /etc/nginx/sites-available/emotion-system /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl restart nginx
```

#### 步骤5：使用Systemd管理服务

创建 `/etc/systemd/system/emotion-backend.service`:

```ini
[Unit]
Description=Emotion Detection Backend
After=network.target

[Service]
Type=notify
User=www-data
WorkingDirectory=/opt/emotion-system/python-backend
Environment="PATH=/opt/emotion-system/python-backend/venv/bin"
ExecStart=/opt/emotion-system/python-backend/venv/bin/gunicorn \
    -w 4 \
    -b 127.0.0.1:5000 \
    --timeout 120 \
    app:app

Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
```

启动服务：
```bash
sudo systemctl daemon-reload
sudo systemctl enable emotion-backend
sudo systemctl start emotion-backend
```

### 方案2：Docker容器部署

#### 创建Docker Compose配置

创建 `docker-compose.yml`:

```yaml
version: '3.8'

services:
  # Python后端
  backend:
    build:
      context: ./python-backend
      dockerfile: Dockerfile
    ports:
      - "5000:5000"
    environment:
      - PYTHON_PORT=5000
    volumes:
      - ./python-backend:/app
    restart: always

  # React前端
  frontend:
    build:
      context: .
      dockerfile: Dockerfile
    ports:
      - "3000:3000"
    environment:
      - VITE_API_URL=http://localhost:5000
    depends_on:
      - backend
    restart: always

  # Nginx反向代理
  nginx:
    image: nginx:alpine
    ports:
      - "80:80"
      - "443:443"
    volumes:
      - ./nginx.conf:/etc/nginx/nginx.conf:ro
      - ./ssl:/etc/nginx/ssl:ro
    depends_on:
      - backend
      - frontend
    restart: always
```

#### 创建Dockerfile

**Python后端 (python-backend/Dockerfile):**

```dockerfile
FROM python:3.11-slim

WORKDIR /app

# 安装系统依赖
RUN apt-get update && apt-get install -y \
    libopencv-dev \
    && rm -rf /var/lib/apt/lists/*

# 复制依赖文件
COPY requirements.txt .

# 安装Python依赖
RUN pip install --no-cache-dir -r requirements.txt

# 复制应用文件
COPY app.py .

# 暴露端口
EXPOSE 5000

# 启动应用
CMD ["python3", "app.py"]
```

**React前端 (Dockerfile):**

```dockerfile
FROM node:20-alpine AS builder

WORKDIR /app

COPY package.json pnpm-lock.yaml ./
RUN npm install -g pnpm && pnpm install

COPY . .
RUN pnpm build

FROM node:20-alpine

WORKDIR /app

COPY --from=builder /app/dist ./dist
COPY --from=builder /app/package.json ./

RUN npm install -g pnpm && pnpm install --prod

EXPOSE 3000

CMD ["pnpm", "preview"]
```

#### 启动容器

```bash
docker-compose up -d

# 查看日志
docker-compose logs -f

# 停止服务
docker-compose down
```

### 方案3：云平台部署

#### AWS部署

1. **后端部署到EC2:**
   ```bash
   # 启动EC2实例 (Ubuntu 20.04+)
   # 按照"同一服务器部署"步骤操作
   ```

2. **前端部署到S3 + CloudFront:**
   ```bash
   # 构建前端
   pnpm build
   
   # 上传到S3
   aws s3 sync dist/ s3://my-bucket/
   
   # 创建CloudFront分布
   ```

#### Heroku部署

1. **后端部署:**
   ```bash
   heroku login
   heroku create emotion-backend
   git push heroku main
   ```

2. **前端部署:**
   ```bash
   heroku create emotion-frontend
   git push heroku main
   ```

## 环境变量配置

### 后端环境变量

创建 `python-backend/.env`:

```env
PYTHON_PORT=5000
CORS_ORIGINS=http://localhost:3000,https://example.com
LOG_LEVEL=INFO
MODEL_SIZE=n  # n(nano), s(small), m(medium)
```

### 前端环境变量

创建 `.env`:

```env
VITE_API_URL=http://localhost:5000
VITE_WS_URL=ws://localhost:5000
VITE_APP_NAME=情感交互系统
```

## 性能优化

### 1. 启用HTTPS

```bash
# 使用Let's Encrypt
sudo apt-get install certbot python3-certbot-nginx
sudo certbot certonly --nginx -d api.example.com
```

### 2. 启用缓存

在Nginx配置中添加：

```nginx
location ~* \.(js|css|png|jpg|jpeg|gif|ico|svg|woff|woff2|ttf|eot)$ {
    expires 1y;
    add_header Cache-Control "public, immutable";
}
```

### 3. 启用Gzip压缩

```nginx
gzip on;
gzip_types text/plain text/css text/javascript application/json;
gzip_min_length 1000;
```

### 4. 使用CDN

- 前端静态文件：使用Cloudflare或AWS CloudFront
- 后端API：使用API Gateway或Cloudflare Workers

## 监控和日志

### 后端日志

```bash
# 查看实时日志
tail -f /var/log/emotion-backend.log

# 使用ELK Stack收集日志
```

### 前端监控

集成Sentry进行错误追踪：

```typescript
import * as Sentry from "@sentry/react";

Sentry.init({
  dsn: "https://your-sentry-dsn@sentry.io/project-id",
  environment: process.env.NODE_ENV,
});
```

## 故障排除

### 问题1: WebSocket连接失败

**检查清单:**
- [ ] 后端服务是否运行
- [ ] 防火墙是否允许WebSocket端口
- [ ] Nginx是否正确配置了WebSocket代理
- [ ] 浏览器控制台是否有错误

**解决方案:**
```bash
# 检查后端服务
curl http://localhost:5000/health

# 检查端口
netstat -tlnp | grep 5000

# 查看Nginx错误日志
sudo tail -f /var/log/nginx/error.log
```

### 问题2: GPU内存不足

**解决方案:**
- 使用更小的模型 (yolov11n.pt)
- 启用模型量化
- 增加服务器内存

### 问题3: 检测延迟高

**优化方案:**
- 使用GPU加速
- 减少输入图像分辨率
- 增加服务器CPU核心数
- 使用负载均衡

## 安全建议

1. **启用HTTPS/SSL**
2. **设置速率限制**
3. **验证API请求**
4. **定期更新依赖**
5. **监控异常流量**
6. **备份数据库**

## 支持和反馈

如有问题，请提交Issue或联系技术支持。
