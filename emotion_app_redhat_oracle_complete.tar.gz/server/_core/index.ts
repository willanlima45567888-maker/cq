import "dotenv/config";
import express from "express";
import { createServer } from "http";
import { WebSocketServer, WebSocket } from "ws";
import net from "net";
import { createExpressMiddleware } from "@trpc/server/adapters/express";
import { registerOAuthRoutes } from "./oauth";
import { appRouter } from "../routers";
import { createContext } from "./context";
import { serveStatic, setupVite } from "./vite";

function isPortAvailable(port: number): Promise<boolean> {
  return new Promise(resolve => {
    const server = net.createServer();
    server.listen(port, () => {
      server.close(() => resolve(true));
    });
    server.on("error", () => resolve(false));
  });
}

async function findAvailablePort(startPort: number = 3000): Promise<number> {
  for (let port = startPort; port < startPort + 20; port++) {
    if (await isPortAvailable(port)) {
      return port;
    }
  }
  throw new Error(`No available port found starting from ${startPort}`);
}

async function startServer() {
  const app = express();
  const server = createServer(app);
  
  // 创建WebSocket服务器用于代理Python后端的WebSocket连接
  const wss = new WebSocketServer({ server, path: "/api/ws/detect" });
  
  // Configure body parser with larger size limit for file uploads
  app.use(express.json({ limit: "50mb" }));
  app.use(express.urlencoded({ limit: "50mb", extended: true }));
  
  // 添加CORS头支持
  app.use((req, res, next) => {
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS");
    res.header("Access-Control-Allow-Headers", "Content-Type, Authorization");
    if (req.method === "OPTIONS") {
      res.sendStatus(200);
    } else {
      next();
    }
  });
  
  // OAuth callback under /api/oauth/callback
  registerOAuthRoutes(app);
  
  // WebSocket代理：转发客户端请求到Python后端
  wss.on("connection", (ws: WebSocket) => {
    console.log("[WebSocket] 客户端已连接");
    
    // 连接到Python后端
    const pythonWsUrl = process.env.PYTHON_BACKEND_WS || "ws://localhost:5000/ws/detect";
    console.log(`[WebSocket] 正在连接到Python后端: ${pythonWsUrl}`);
    
    const pythonWs = new WebSocket(pythonWsUrl);
    
    pythonWs.on("open", () => {
      console.log("[WebSocket] 已连接到Python后端");
    });
    
    pythonWs.on("message", (data: Buffer) => {
      // 转发Python后端的消息到客户端
      if (ws.readyState === ws.OPEN) {
        ws.send(data);
      }
    });
    
    pythonWs.on("error", (error: Error) => {
      console.error("[WebSocket] Python后端错误:", error.message);
      if (ws.readyState === ws.OPEN) {
        ws.send(JSON.stringify({ error: "后端连接失败" }));
      }
    });
    
    pythonWs.on("close", () => {
      console.log("[WebSocket] Python后端连接已关闭");
      if (ws.readyState === ws.OPEN) {
        ws.close();
      }
    });
    
    // 处理客户端消息
    ws.on("message", (data: Buffer) => {
      if (pythonWs.readyState === pythonWs.OPEN) {
        pythonWs.send(data);
      }
    });
    
    ws.on("error", (error: Error) => {
      console.error("[WebSocket] 客户端错误:", error.message);
    });
    
    ws.on("close", () => {
      console.log("[WebSocket] 客户端已断开");
      if (pythonWs.readyState === pythonWs.OPEN) {
        pythonWs.close();
      }
    });
  });
  
  // tRPC API
  app.use(
    "/api/trpc",
    createExpressMiddleware({
      router: appRouter,
      createContext,
    })
  );
  // development mode uses Vite, production mode uses static files
  if (process.env.NODE_ENV === "development") {
    await setupVite(app, server);
  } else {
    serveStatic(app);
  }

  const preferredPort = parseInt(process.env.PORT || "3000");
  const port = await findAvailablePort(preferredPort);

  if (port !== preferredPort) {
    console.log(`Port ${preferredPort} is busy, using port ${port} instead`);
  }

  server.listen(port, () => {
    console.log(`Server running on http://localhost:${port}/`);
    console.log(`WebSocket代理已启动: ws://localhost:${port}/api/ws/detect`);
    console.log(`Python后端地址: ${process.env.PYTHON_BACKEND_WS || "ws://localhost:5000/ws/detect"}`);
  });
}

startServer().catch((error) => {
  console.error("启动服务器失败:", error);
  process.exit(1);
});
