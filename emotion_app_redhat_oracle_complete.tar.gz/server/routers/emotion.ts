import { protectedProcedure, router } from "../_core/trpc";
import { z } from "zod";
import { getDb } from "../db";
import { userSettings, emotionHistory, customResponses } from "../../drizzle/schema";
import { eq, and } from "drizzle-orm";
import { invokeLLM } from "../_core/llm";

export const emotionRouter = router({
  getUserSettings: protectedProcedure.query(async ({ ctx }) => {
    const db = await getDb();
    if (!db) return null;

    const settings = await db
      .select()
      .from(userSettings)
      .where(eq(userSettings.userId, ctx.user.id))
      .limit(1);

    if (settings.length === 0) {
      await db.insert(userSettings).values({
        userId: ctx.user.id,
        voiceId: "default",
        speechRate: "1.0" as any,
        volume: "1.0" as any,
        language: "zh-CN",
        autoRespond: 1,
      });

      return {
        userId: ctx.user.id,
        voiceId: "default",
        speechRate: "1.0",
        volume: "1.0",
        language: "zh-CN",
        autoRespond: 1,
      };
    }

    return settings[0];
  }),

  saveDetectionHistory: protectedProcedure
    .input(
      z.object({
        emotion: z.enum(["happy", "sad", "angry", "fearful", "neutral"]),
        confidence: z.number().min(0).max(1),
        response: z.string(),
        voiceUsed: z.string().optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) return null;

      return await db.insert(emotionHistory).values({
        userId: ctx.user.id,
        emotion: input.emotion,
        confidence: input.confidence.toString() as any,
        response: input.response,
        voiceUsed: input.voiceUsed || "default",
      });
    }),

  getDetectionHistory: protectedProcedure
    .input(
      z.object({
        limit: z.number().default(50),
        offset: z.number().default(0),
      })
    )
    .query(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) return [];

      return await db
        .select()
        .from(emotionHistory)
        .where(eq(emotionHistory.userId, ctx.user.id))
        .limit(input.limit)
        .offset(input.offset);
    }),

  // AI智能对话功能
  generateAIResponse: protectedProcedure
    .input(
      z.object({
        userMessage: z.string(),
        emotion: z.enum(["happy", "sad", "angry", "fearful", "neutral"]),
        conversationHistory: z.array(
          z.object({
            role: z.enum(["user", "assistant"]),
            content: z.string(),
          })
        ).optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      try {
        // 构建系统提示词
        const emotionContext = {
          happy: "用户现在很开心，保持积极乐观的语气",
          sad: "用户现在很伤心，提供温暖的安慰和鼓励",
          angry: "用户现在很生气，帮助用户冷静下来，理解他的感受",
          fearful: "用户现在很害怕，提供安心和支持",
          neutral: "用户现在很平静，进行友好的对话",
        };

        const systemPrompt = `你是一个富有同情心的AI助手，专门帮助用户处理情感问题。
当前用户的情感状态：${emotionContext[input.emotion]}

你的回应应该：
1. 表现出真诚的同情和理解
2. 提供个性化的建议或安慰
3. 鼓励用户表达自己的感受
4. 保持对话自然流畅
5. 回应简洁有力，适合语音播放（100-200字以内）

请用中文回应。`;

        // 构建对话历史
        const messages = [
          { role: "system" as const, content: systemPrompt },
          ...(input.conversationHistory || []),
          { role: "user" as const, content: input.userMessage },
        ];

        // 调用LLM生成回应
        const response = await invokeLLM({
          messages: messages as any,
        });

        const aiResponse = typeof response.choices[0]?.message?.content === 'string' 
          ? response.choices[0].message.content 
          : "我理解你的感受，一切都会好起来的。";

        // 保存对话到数据库
        const db = await getDb();
        if (db) {
          await db.insert(emotionHistory).values({
            userId: ctx.user.id,
            emotion: input.emotion,
            confidence: "0.9000" as any,
            response: aiResponse,
            voiceUsed: "ai",
          });
        }

        return {
          success: true,
          response: aiResponse,
          emotion: input.emotion,
        };
      } catch (error) {
        console.error("AI response generation failed:", error);
        return {
          success: false,
          response: "抱歉，我暂时无法回应。请稍后再试。",
          emotion: input.emotion,
        };
      }
    }),

  // 获取对话历史
  getConversationHistory: protectedProcedure
    .input(
      z.object({
        limit: z.number().default(20),
      })
    )
    .query(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) return [];

      const history = await db
        .select()
        .from(emotionHistory)
        .where(eq(emotionHistory.userId, ctx.user.id))
        .limit(input.limit);

      // 转换为对话格式
      return history.map((item) => ({
        role: item.voiceUsed === "ai" ? "assistant" : "user",
        content: item.response,
        emotion: item.emotion,
        timestamp: item.detectedAt,
      }));
    }),

  // 获取情感统计
  getEmotionStats: protectedProcedure.query(async ({ ctx }) => {
    const db = await getDb();
    if (!db) return null;

    const history = await db
      .select()
      .from(emotionHistory)
      .where(eq(emotionHistory.userId, ctx.user.id));

    const stats = {
      total: history.length,
      byEmotion: {
        happy: 0,
        sad: 0,
        angry: 0,
        fearful: 0,
        neutral: 0,
      },
      averageConfidence: 0,
    };

    let totalConfidence = 0;
    history.forEach((item) => {
      const emotion = item.emotion as keyof typeof stats.byEmotion;
      stats.byEmotion[emotion]++;
      totalConfidence += parseFloat(item.confidence as string);
    });

    if (history.length > 0) {
      stats.averageConfidence = totalConfidence / history.length;
    }

    return stats;
  }),

  // 保存自定义回应
  saveCustomResponse: protectedProcedure
    .input(
      z.object({
        emotion: z.enum(["happy", "sad", "angry", "fearful", "neutral"]),
        responseText: z.string(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) return null;

      return await db.insert(customResponses).values({
        userId: ctx.user.id,
        emotion: input.emotion,
        responseText: input.responseText,
        isActive: 1,
      });
    }),

  // 获取自定义回应
  getCustomResponses: protectedProcedure
    .input(
      z.object({
        emotion: z.enum(["happy", "sad", "angry", "fearful", "neutral"]).optional(),
      })
    )
    .query(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) return [];

      let query = db
        .select()
        .from(customResponses)
        .where(and(
          eq(customResponses.userId, ctx.user.id),
          eq(customResponses.isActive, 1)
        ));

      if (input.emotion) {
        query = db
          .select()
          .from(customResponses)
          .where(and(
            eq(customResponses.userId, ctx.user.id),
            eq(customResponses.emotion, input.emotion),
            eq(customResponses.isActive, 1)
          ));
      }

      return await query;
    }),
});
