import { int, mysqlEnum, mysqlTable, text, timestamp, varchar, decimal } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/**
 * User settings table - stores voice preferences and customization
 */
export const userSettings = mysqlTable("userSettings", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  voiceId: varchar("voiceId", { length: 64 }).default("default").notNull(),
  speechRate: decimal("speechRate", { precision: 3, scale: 1 }).default("1.0").notNull(),
  volume: decimal("volume", { precision: 3, scale: 2 }).default("1.0").notNull(),
  language: varchar("language", { length: 10 }).default("zh-CN").notNull(),
  autoRespond: int("autoRespond").default(1).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type UserSettings = typeof userSettings.$inferSelect;
export type InsertUserSettings = typeof userSettings.$inferInsert;

/**
 * Emotion detection history - stores all emotion detections
 */
export const emotionHistory = mysqlTable("emotionHistory", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  emotion: mysqlEnum("emotion", ["happy", "sad", "angry", "fearful", "neutral"]).notNull(),
  confidence: decimal("confidence", { precision: 5, scale: 4 }).notNull(),
  response: text("response"),
  voiceUsed: varchar("voiceUsed", { length: 64 }),
  detectedAt: timestamp("detectedAt").defaultNow().notNull(),
});

export type EmotionHistory = typeof emotionHistory.$inferSelect;
export type InsertEmotionHistory = typeof emotionHistory.$inferInsert;

/**
 * Custom voice responses - allows users to customize responses for each emotion
 */
export const customResponses = mysqlTable("customResponses", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  emotion: mysqlEnum("emotion", ["happy", "sad", "angry", "fearful", "neutral"]).notNull(),
  responseText: text("responseText").notNull(),
  isActive: int("isActive").default(1).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type CustomResponse = typeof customResponses.$inferSelect;
export type InsertCustomResponse = typeof customResponses.$inferInsert;