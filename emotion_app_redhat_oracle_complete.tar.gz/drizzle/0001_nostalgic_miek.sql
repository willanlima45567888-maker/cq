CREATE TABLE `customResponses` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`emotion` enum('happy','sad','angry','fearful','neutral') NOT NULL,
	`responseText` text NOT NULL,
	`isActive` int NOT NULL DEFAULT 1,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `customResponses_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `emotionHistory` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`emotion` enum('happy','sad','angry','fearful','neutral') NOT NULL,
	`confidence` decimal(5,4) NOT NULL,
	`response` text,
	`voiceUsed` varchar(64),
	`detectedAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `emotionHistory_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `userSettings` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`voiceId` varchar(64) NOT NULL DEFAULT 'default',
	`speechRate` decimal(3,1) NOT NULL DEFAULT '1.0',
	`volume` decimal(3,2) NOT NULL DEFAULT '1.0',
	`language` varchar(10) NOT NULL DEFAULT 'zh-CN',
	`autoRespond` int NOT NULL DEFAULT 1,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `userSettings_id` PRIMARY KEY(`id`)
);
