/**
 * 情感检测客户端
 * 处理与YOLOv11后端的WebSocket通信
 */

export interface DetectionBox {
  x: number;
  y: number;
  width: number;
  height: number;
}

export interface Detection {
  emotion: string;
  confidence: number;
  box: DetectionBox;
}

export interface DetectionResult {
  frame_id: number;
  detections: Detection[];
  image: string; // base64编码的图像
  timestamp: string;
  error?: string;
}

export class EmotionDetectionClient {
  private ws: WebSocket | null = null;
  private url: string;
  private frameId: number = 0;
  private isConnected: boolean = false;
  private reconnectAttempts: number = 0;
  private maxReconnectAttempts: number = 5;
  private reconnectDelay: number = 1000;

  private onMessageCallback: ((result: DetectionResult) => void) | null = null;
  private onErrorCallback: ((error: string) => void) | null = null;
  private onConnectCallback: (() => void) | null = null;
  private onDisconnectCallback: (() => void) | null = null;

  constructor(url?: string) {
    // 如果没有提供URL，根据当前环境自动构建
    if (url) {
      this.url = url;
    } else {
      // 检测当前页面是HTTPS还是HTTP
      const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
      // 使用相对路径连接到同一主机的后端
      // 这样可以在Manus平台上正确路由到后端服务
      const host = window.location.host;
      this.url = `${protocol}//${host}/api/ws/detect`;
    }
  }

  /**
   * 连接到WebSocket服务器
   */
  public connect(): Promise<void> {
    return new Promise((resolve, reject) => {
      try {
        console.log(`🔌 正在连接到: ${this.url}`);
        this.ws = new WebSocket(this.url);

        this.ws.onopen = () => {
          console.log("✅ WebSocket已连接");
          this.isConnected = true;
          this.reconnectAttempts = 0;
          if (this.onConnectCallback) {
            this.onConnectCallback();
          }
          resolve();
        };

        this.ws.onmessage = (event) => {
          try {
            const result: DetectionResult = JSON.parse(event.data);
            if (this.onMessageCallback) {
              this.onMessageCallback(result);
            }
          } catch (error) {
            console.error("解析WebSocket消息失败:", error);
            if (this.onErrorCallback) {
              this.onErrorCallback("解析消息失败");
            }
          }
        };

        this.ws.onerror = (event) => {
          console.error("❌ WebSocket错误:", event);
          this.isConnected = false;
          const errorMsg = `WebSocket连接错误 (URL: ${this.url})`;
          if (this.onErrorCallback) {
            this.onErrorCallback(errorMsg);
          }
          reject(new Error(errorMsg));
        };

        this.ws.onclose = () => {
          console.log("❌ WebSocket已断开");
          this.isConnected = false;
          if (this.onDisconnectCallback) {
            this.onDisconnectCallback();
          }
          this.attemptReconnect();
        };
      } catch (error) {
        console.error("创建WebSocket连接失败:", error);
        reject(error);
      }
    });
  }

  /**
   * 尝试重新连接
   */
  private attemptReconnect(): void {
    if (this.reconnectAttempts < this.maxReconnectAttempts) {
      this.reconnectAttempts++;
      const delay = this.reconnectDelay * Math.pow(2, this.reconnectAttempts - 1);
      console.log(`⏳ 将在${delay}ms后尝试重新连接... (${this.reconnectAttempts}/${this.maxReconnectAttempts})`);
      
      setTimeout(() => {
        this.connect().catch((error) => {
          console.error("重新连接失败:", error);
        });
      }, delay);
    } else {
      console.error("❌ 达到最大重新连接次数");
      if (this.onErrorCallback) {
        this.onErrorCallback("无法连接到服务器");
      }
    }
  }

  /**
   * 断开连接
   */
  public disconnect(): void {
    if (this.ws) {
      this.ws.close();
      this.ws = null;
      this.isConnected = false;
    }
  }

  /**
   * 发送视频帧进行检测
   */
  public async sendFrame(canvas: HTMLCanvasElement): Promise<void> {
    if (!this.isConnected || !this.ws) {
      throw new Error("WebSocket未连接");
    }

    return new Promise((resolve, reject) => {
      canvas.toBlob(
        (blob) => {
          if (!blob) {
            reject(new Error("无法创建blob"));
            return;
          }

          const reader = new FileReader();
          reader.onload = (e) => {
            try {
              const base64 = (e.target?.result as string).split(",")[1];
              const message = {
                image: base64,
                frame_id: this.frameId++,
              };

              if (this.ws && this.ws.readyState === WebSocket.OPEN) {
                this.ws.send(JSON.stringify(message));
                resolve();
              } else {
                reject(new Error("WebSocket连接已关闭"));
              }
            } catch (error) {
              reject(error);
            }
          };

          reader.onerror = () => {
            reject(new Error("读取blob失败"));
          };

          reader.readAsDataURL(blob);
        },
        "image/jpeg",
        0.8 // 质量80%以减少数据量
      );
    });
  }

  /**
   * 注册消息回调
   */
  public onMessage(callback: (result: DetectionResult) => void): void {
    this.onMessageCallback = callback;
  }

  /**
   * 注册错误回调
   */
  public onError(callback: (error: string) => void): void {
    this.onErrorCallback = callback;
  }

  /**
   * 注册连接成功回调
   */
  public onConnect(callback: () => void): void {
    this.onConnectCallback = callback;
  }

  /**
   * 注册断开连接回调
   */
  public onDisconnect(callback: () => void): void {
    this.onDisconnectCallback = callback;
  }

  /**
   * 获取连接状态
   */
  public getIsConnected(): boolean {
    return this.isConnected;
  }

  /**
   * 获取当前帧ID
   */
  public getFrameId(): number {
    return this.frameId;
  }
}

// 导出单例
let clientInstance: EmotionDetectionClient | null = null;

export function getEmotionDetectionClient(url?: string): EmotionDetectionClient {
  if (!clientInstance) {
    clientInstance = new EmotionDetectionClient(url);
  }
  return clientInstance;
}
