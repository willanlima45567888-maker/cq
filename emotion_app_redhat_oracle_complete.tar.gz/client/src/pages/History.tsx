import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { ArrowLeft, BarChart3 } from "lucide-react";
import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { format } from "date-fns";
import { zhCN } from "date-fns/locale";

const EMOTIONS = {
  happy: { label: "开心", emoji: "😊", color: "bg-yellow-100", textColor: "text-yellow-600" },
  sad: { label: "悲伤", emoji: "😢", color: "bg-blue-100", textColor: "text-blue-600" },
  angry: { label: "生气", emoji: "😠", color: "bg-red-100", textColor: "text-red-600" },
  fearful: { label: "恐惧", emoji: "😨", color: "bg-purple-100", textColor: "text-purple-600" },
  neutral: { label: "平静", emoji: "😐", color: "bg-gray-100", textColor: "text-gray-600" },
};

export default function History() {
  const { user } = useAuth();
  const [, setLocation] = useLocation();

  const { data: history } = trpc.emotion.getDetectionHistory.useQuery(
    { limit: 100, offset: 0 },
    { enabled: !!user }
  );

  const { data: stats } = trpc.emotion.getStatistics.useQuery(undefined, {
    enabled: !!user,
  });

  const emotionData = history || [];

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-white">
      {/* Header */}
      <header className="sticky top-0 z-50 bg-white border-b border-blue-100">
        <div className="container max-w-6xl mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Button
              onClick={() => setLocation("/app")}
              variant="ghost"
              size="sm"
              className="gap-2"
            >
              <ArrowLeft className="w-4 h-4" /> 返回
            </Button>
            <h1 className="text-2xl font-bold text-gray-900">检测历史</h1>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container max-w-6xl mx-auto px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6 mb-8">
          {/* Statistics Cards */}
          {stats && (
            <>
              <Card className="border-blue-200">
                <CardContent className="pt-6">
                  <div className="text-center">
                    <div className="text-3xl font-bold text-blue-600">{stats.total}</div>
                    <p className="text-sm text-gray-600 mt-2">总检测次数</p>
                  </div>
                </CardContent>
              </Card>

              <Card className="border-blue-200">
                <CardContent className="pt-6">
                  <div className="text-center">
                    <div className="text-3xl font-bold text-blue-600">
                      {(stats.averageConfidence * 100).toFixed(1)}%
                    </div>
                    <p className="text-sm text-gray-600 mt-2">平均置信度</p>
                  </div>
                </CardContent>
              </Card>

              <Card className="border-blue-200">
                <CardContent className="pt-6">
                  <div className="text-center">
                    <div className="text-3xl font-bold text-blue-600">
                      {Math.max(...Object.values(stats.emotions))}
                    </div>
                    <p className="text-sm text-gray-600 mt-2">最常见表情</p>
                  </div>
                </CardContent>
              </Card>

              <Card className="border-blue-200">
                <CardContent className="pt-6">
                  <div className="text-center">
                    <div className="text-3xl font-bold text-blue-600">
                      {Object.values(stats.emotions as Record<string, number>).filter((v: number) => v > 0).length}
                    </div>
                    <p className="text-sm text-gray-600 mt-2">检测到的表情类型</p>
                  </div>
                </CardContent>
              </Card>
            </>
          )}
        </div>

        {/* Emotion Distribution */}
        {stats && (
          <Card className="border-blue-200 mb-8">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <BarChart3 className="w-5 h-5 text-blue-600" />
                表情分布
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
                {Object.entries(stats.emotions as Record<string, number>).map(([emotion, count]: [string, number]) => (
                  <div key={emotion} className="text-center">
                    <div className="text-2xl mb-2">
                      {EMOTIONS[emotion as keyof typeof EMOTIONS].emoji}
                    </div>
                    <div className="text-sm font-semibold text-gray-900">
                      {EMOTIONS[emotion as keyof typeof EMOTIONS].label}
                    </div>
                    <div className="text-lg font-bold text-blue-600 mt-1">{count as number}</div>
                    <div className="text-xs text-gray-500">
                      {stats.total > 0 ? (((count as number) / stats.total) * 100).toFixed(1) : 0}%
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}

        {/* History List */}
        <Card className="border-blue-200">
          <CardHeader>
            <CardTitle>最近检测记录</CardTitle>
            <CardDescription>显示最近100条检测记录</CardDescription>
          </CardHeader>
          <CardContent>
            {emotionData.length === 0 ? (
              <div className="text-center py-8 text-gray-500">
                <p>暂无检测记录</p>
              </div>
            ) : (
              <div className="space-y-3 max-h-[600px] overflow-y-auto">
                {emotionData.map((record, idx) => {
                  const emotionInfo = EMOTIONS[record.emotion as keyof typeof EMOTIONS];
                  return (
                    <div
                      key={idx}
                      className={`p-4 rounded-lg border ${emotionInfo.color} flex items-start justify-between`}
                    >
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-2">
                          <span className="text-2xl">{emotionInfo.emoji}</span>
                          <span className={`font-semibold ${emotionInfo.textColor}`}>
                            {emotionInfo.label}
                          </span>
                          <span className="text-sm text-gray-600">
                            置信度: {(parseFloat(record.confidence as any) * 100).toFixed(1)}%
                          </span>
                        </div>
                        <p className="text-sm text-gray-700 mb-2">"{record.response}"</p>
                        <p className="text-xs text-gray-500">
                          {format(new Date(record.detectedAt), "yyyy年MM月dd日 HH:mm:ss", {
                            locale: zhCN,
                          })}
                        </p>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </CardContent>
        </Card>
      </main>
    </div>
  );
}
