import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Loader2, ArrowRight, Smile, Brain, Mic2, Zap } from "lucide-react";
import { getLoginUrl } from "@/const";
import { useLocation } from "wouter";

export default function Home() {
  const { user, loading, isAuthenticated } = useAuth();
  const [, setLocation] = useLocation();

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 to-white">
        <Loader2 className="w-8 h-8 animate-spin text-blue-600" />
      </div>
    );
  }

  if (isAuthenticated) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-blue-50">
        {/* Navigation */}
        <nav className="sticky top-0 z-50 bg-white/80 backdrop-blur-md border-b border-blue-100">
          <div className="container max-w-6xl mx-auto px-4 py-4 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-10 h-10 bg-gradient-to-br from-blue-600 to-blue-700 rounded-lg flex items-center justify-center">
                <Smile className="w-6 h-6 text-white" />
              </div>
              <span className="text-xl font-bold bg-gradient-to-r from-blue-600 to-blue-700 bg-clip-text text-transparent">
                情感交互应用
              </span>
            </div>
            <div className="flex items-center gap-4">
              <span className="text-sm text-gray-600">欢迎, {user?.name || "用户"}</span>
              <Button
                onClick={() => setLocation("/app")}
                className="bg-blue-600 hover:bg-blue-700 text-white"
              >
                进入应用
              </Button>
            </div>
          </div>
        </nav>

        {/* Hero Section */}
        <section className="container max-w-6xl mx-auto px-4 py-20">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div className="space-y-6">
              <div className="inline-block px-4 py-2 bg-blue-100 text-blue-700 rounded-full text-sm font-semibold">
                🚀 基于YOLOv11的AI情感识别
              </div>
              <h1 className="text-5xl lg:text-6xl font-bold text-gray-900 leading-tight">
                实时智能<br />
                <span className="bg-gradient-to-r from-blue-600 to-blue-700 bg-clip-text text-transparent">
                  情感交互系统
                </span>
              </h1>
              <p className="text-xl text-gray-600 leading-relaxed">
                通过先进的深度学习模型实时检测面部表情，并根据情感状态提供智能文字和语音回应。
              </p>
              <div className="flex flex-col sm:flex-row gap-4 pt-4">
                <Button
                  onClick={() => setLocation("/app")}
                  size="lg"
                  className="bg-blue-600 hover:bg-blue-700 text-white gap-2"
                >
                  立即体验 <ArrowRight className="w-4 h-4" />
                </Button>
              </div>
            </div>
            <div className="relative">
              <div className="w-full aspect-square bg-gradient-to-br from-blue-100 to-blue-50 rounded-2xl flex items-center justify-center shadow-2xl">
                <Smile className="w-32 h-32 text-blue-300" />
              </div>
            </div>
          </div>
        </section>

        {/* Features Section */}
        <section className="bg-white py-20 border-t border-blue-100">
          <div className="container max-w-6xl mx-auto px-4">
            <div className="text-center mb-16">
              <h2 className="text-4xl font-bold text-gray-900 mb-4">核心功能</h2>
              <p className="text-xl text-gray-600">完整的情感识别和交互系统</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {[
                {
                  icon: <Brain className="w-8 h-8" />,
                  title: "实时表情检测",
                  description: "基于YOLOv11的高精度表情识别，支持5种基本情感",
                },
                {
                  icon: <Smile className="w-8 h-8" />,
                  title: "智能情感回应",
                  description: "根据检测到的表情自动生成合适的文字回应",
                },
                {
                  icon: <Mic2 className="w-8 h-8" />,
                  title: "语音合成",
                  description: "支持100+种语音，可自定义语速和音量",
                },
                {
                  icon: <Zap className="w-8 h-8" />,
                  title: "实时处理",
                  description: "30+ FPS的检测速度，流畅的用户体验",
                },
              ].map((feature, idx) => (
                <div key={idx} className="p-6 bg-gradient-to-br from-blue-50 to-white rounded-lg border border-blue-100 hover:shadow-lg transition">
                  <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center text-blue-600 mb-4">
                    {feature.icon}
                  </div>
                  <h3 className="text-lg font-semibold text-gray-900 mb-2">{feature.title}</h3>
                  <p className="text-gray-600">{feature.description}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="bg-gradient-to-r from-blue-600 to-blue-700 py-20">
          <div className="container max-w-6xl mx-auto px-4 text-center text-white">
            <h2 className="text-4xl font-bold mb-4">准备好开始了吗？</h2>
            <p className="text-xl mb-8 opacity-90">点击按钮进入应用，开始体验智能情感交互的魅力。</p>
            <Button
              onClick={() => setLocation("/app")}
              size="lg"
              className="bg-white text-blue-600 hover:bg-blue-50 gap-2"
            >
              进入应用 <ArrowRight className="w-4 h-4" />
            </Button>
          </div>
        </section>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-blue-50">
      {/* Navigation */}
      <nav className="sticky top-0 z-50 bg-white/80 backdrop-blur-md border-b border-blue-100">
        <div className="container max-w-6xl mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-10 h-10 bg-gradient-to-br from-blue-600 to-blue-700 rounded-lg flex items-center justify-center">
              <Smile className="w-6 h-6 text-white" />
            </div>
            <span className="text-xl font-bold bg-gradient-to-r from-blue-600 to-blue-700 bg-clip-text text-transparent">
              情感交互应用
            </span>
          </div>
          <Button
            onClick={() => (window.location.href = getLoginUrl())}
            className="bg-blue-600 hover:bg-blue-700 text-white"
          >
            登录
          </Button>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="container max-w-6xl mx-auto px-4 py-20">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div className="space-y-6">
            <div className="inline-block px-4 py-2 bg-blue-100 text-blue-700 rounded-full text-sm font-semibold">
              🚀 基于YOLOv11的AI情感识别
            </div>
            <h1 className="text-5xl lg:text-6xl font-bold text-gray-900 leading-tight">
              实时智能<br />
              <span className="bg-gradient-to-r from-blue-600 to-blue-700 bg-clip-text text-transparent">
                情感交互系统
              </span>
            </h1>
            <p className="text-xl text-gray-600 leading-relaxed">
              通过先进的深度学习模型实时检测面部表情，并根据情感状态提供智能文字和语音回应。
            </p>
            <div className="flex flex-col sm:flex-row gap-4 pt-4">
              <Button
                onClick={() => (window.location.href = getLoginUrl())}
                size="lg"
                className="bg-blue-600 hover:bg-blue-700 text-white gap-2"
              >
                立即体验 <ArrowRight className="w-4 h-4" />
              </Button>
            </div>
          </div>
          <div className="relative">
            <div className="w-full aspect-square bg-gradient-to-br from-blue-100 to-blue-50 rounded-2xl flex items-center justify-center shadow-2xl">
              <Smile className="w-32 h-32 text-blue-300" />
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="bg-white py-20 border-t border-blue-100">
        <div className="container max-w-6xl mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">核心功能</h2>
            <p className="text-xl text-gray-600">完整的情感识别和交互系统</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {[
              {
                icon: <Brain className="w-8 h-8" />,
                title: "实时表情检测",
                description: "基于YOLOv11的高精度表情识别，支持5种基本情感",
              },
              {
                icon: <Smile className="w-8 h-8" />,
                title: "智能情感回应",
                description: "根据检测到的表情自动生成合适的文字回应",
              },
              {
                icon: <Mic2 className="w-8 h-8" />,
                title: "语音合成",
                description: "支持100+种语音，可自定义语速和音量",
              },
              {
                icon: <Zap className="w-8 h-8" />,
                title: "实时处理",
                description: "30+ FPS的检测速度，流畅的用户体验",
              },
            ].map((feature, idx) => (
              <div key={idx} className="p-6 bg-gradient-to-br from-blue-50 to-white rounded-lg border border-blue-100 hover:shadow-lg transition">
                <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center text-blue-600 mb-4">
                  {feature.icon}
                </div>
                <h3 className="text-lg font-semibold text-gray-900 mb-2">{feature.title}</h3>
                <p className="text-gray-600">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-gradient-to-r from-blue-600 to-blue-700 py-20">
        <div className="container max-w-6xl mx-auto px-4 text-center text-white">
          <h2 className="text-4xl font-bold mb-4">准备好开始了吗？</h2>
          <p className="text-xl mb-8 opacity-90">登录账户，开始体验智能情感交互的魅力。</p>
          <Button
            onClick={() => (window.location.href = getLoginUrl())}
            size="lg"
            className="bg-white text-blue-600 hover:bg-blue-50 gap-2"
          >
            登录进入 <ArrowRight className="w-4 h-4" />
          </Button>
        </div>
      </section>
    </div>
  );
}
