import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Slider } from "@/components/ui/slider";
import { Volume2, ArrowLeft, Save } from "lucide-react";
import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { useState, useEffect } from "react";

export default function Settings() {
  const { user } = useAuth();
  const [, setLocation] = useLocation();
  const [voiceId, setVoiceId] = useState("default");
  const [speechRate, setSpeechRate] = useState([1]);
  const [volume, setVolume] = useState([1]);
  const [language, setLanguage] = useState("zh-CN");
  const [autoRespond, setAutoRespond] = useState(true);

  const { data: settings } = trpc.emotion.getUserSettings.useQuery(undefined, {
    enabled: !!user,
  });

  const updateSettings = trpc.emotion.updateSettings.useMutation();

  useEffect(() => {
    if (settings) {
      setVoiceId(settings.voiceId);
      setSpeechRate([parseFloat(settings.speechRate as any) || 1]);
      setVolume([parseFloat(settings.volume as any) || 1]);
      setLanguage(settings.language);
      setAutoRespond(settings.autoRespond === 1);
    }
  }, [settings]);

  const handleSave = async () => {
    await updateSettings.mutateAsync({
      voiceId,
      speechRate: speechRate[0],
      volume: volume[0],
      language,
      autoRespond: autoRespond ? 1 : 0,
    });

    alert("设置已保存！");
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-white">
      {/* Header */}
      <header className="sticky top-0 z-50 bg-white border-b border-blue-100">
        <div className="container max-w-6xl mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Button
              onClick={() => setLocation("/app")}
              variant="ghost"
              size="sm"
              className="gap-2"
            >
              <ArrowLeft className="w-4 h-4" /> 返回
            </Button>
            <h1 className="text-2xl font-bold text-gray-900">设置</h1>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container max-w-2xl mx-auto px-4 py-8">
        <div className="space-y-6">
          {/* Voice Settings */}
          <Card className="border-blue-200">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Volume2 className="w-5 h-5 text-blue-600" />
                语音设置
              </CardTitle>
              <CardDescription>自定义语音合成参数</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Voice Selection */}
              <div className="space-y-2">
                <label className="text-sm font-medium text-gray-700">选择语音</label>
                <select
                  value={voiceId}
                  onChange={(e) => setVoiceId(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  <option value="default">默认语音</option>
                  <option value="male-1">男性语音 1</option>
                  <option value="male-2">男性语音 2</option>
                  <option value="female-1">女性语音 1</option>
                  <option value="female-2">女性语音 2</option>
                </select>
              </div>

              {/* Speech Rate */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <label className="text-sm font-medium text-gray-700">语速</label>
                  <span className="text-sm text-gray-600">
                    {speechRate[0] < 1 ? "慢" : speechRate[0] === 1 ? "正常" : "快"}
                  </span>
                </div>
                <Slider
                  value={speechRate}
                  onValueChange={setSpeechRate}
                  min={0.5}
                  max={2}
                  step={0.1}
                />
                <div className="flex justify-between text-xs text-gray-500">
                  <span>0.5x</span>
                  <span>1.0x</span>
                  <span>2.0x</span>
                </div>
              </div>

              {/* Volume */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <label className="text-sm font-medium text-gray-700">音量</label>
                  <span className="text-sm text-gray-600">{(volume[0] * 100).toFixed(0)}%</span>
                </div>
                <Slider
                  value={volume}
                  onValueChange={setVolume}
                  min={0}
                  max={1}
                  step={0.1}
                />
                <div className="flex justify-between text-xs text-gray-500">
                  <span>静音</span>
                  <span>正常</span>
                  <span>最大</span>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Language Settings */}
          <Card className="border-blue-200">
            <CardHeader>
              <CardTitle>语言设置</CardTitle>
              <CardDescription>选择系统使用的语言</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <select
                value={language}
                onChange={(e) => setLanguage(e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="zh-CN">简体中文</option>
                <option value="zh-TW">繁体中文</option>
                <option value="en-US">English</option>
                <option value="ja-JP">日本語</option>
              </select>
            </CardContent>
          </Card>

          {/* Auto Response Settings */}
          <Card className="border-blue-200">
            <CardHeader>
              <CardTitle>自动回应</CardTitle>
              <CardDescription>检测到表情时自动生成回应</CardDescription>
            </CardHeader>
            <CardContent>
              <label className="flex items-center gap-3 cursor-pointer">
                <input
                  type="checkbox"
                  checked={autoRespond}
                  onChange={(e) => setAutoRespond(e.target.checked)}
                  className="w-4 h-4 rounded border-gray-300"
                />
                <span className="text-sm text-gray-700">启用自动回应</span>
              </label>
            </CardContent>
          </Card>

          {/* Save Button */}
          <Button
            onClick={handleSave}
            disabled={updateSettings.isPending}
            className="w-full bg-blue-600 hover:bg-blue-700 text-white gap-2 py-6"
          >
            <Save className="w-4 h-4" />
            {updateSettings.isPending ? "保存中..." : "保存设置"}
          </Button>
        </div>
      </main>
    </div>
  );
}
