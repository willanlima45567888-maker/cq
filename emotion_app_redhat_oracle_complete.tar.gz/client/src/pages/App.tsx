import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Slider } from "@/components/ui/slider";
import { Volume2, Settings, LogOut, Play, Square, History, Mic, Sparkles, Wifi, WifiOff } from "lucide-react";
import { useRef, useEffect, useState } from "react";
import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { getEmotionDetectionClient, type Detection } from "@/lib/emotionDetectionClient";

const EMOTIONS = {
  happy: { label: "开心", emoji: "😊", color: "bg-yellow-100", textColor: "text-yellow-600", boxColor: "#FFD700" },
  sad: { label: "悲伤", emoji: "😢", color: "bg-blue-100", textColor: "text-blue-600", boxColor: "#4169E1" },
  angry: { label: "生气", emoji: "😠", color: "bg-red-100", textColor: "text-red-600", boxColor: "#FF4500" },
  fearful: { label: "恐惧", emoji: "😨", color: "bg-purple-100", textColor: "text-purple-600", boxColor: "#9370DB" },
  neutral: { label: "平静", emoji: "😐", color: "bg-gray-100", textColor: "text-gray-600", boxColor: "#808080" },
};

const DEFAULT_RESPONSES = {
  happy: ["看到你这么开心，我也很高兴！", "你的笑容真灿烂！", "太棒了！"],
  sad: ["别难过，一切都会好起来的。", "我在这里陪着你。", "加油，你可以的！"],
  angry: ["深呼吸，冷静一下。", "我理解你的感受。", "让我们一起解决这个问题。"],
  fearful: ["不用害怕，我在这里。", "你很勇敢，你可以做到。", "一切都会没事的。"],
  neutral: ["你好，有什么我可以帮助的吗？", "今天过得怎么样？", "很高兴见到你。"],
};

export default function AppPage() {
  const { user, logout } = useAuth();
  const [, setLocation] = useLocation();
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const recognitionRef = useRef<any>(null);
  const detectionClientRef = useRef(getEmotionDetectionClient("ws://localhost:5000/ws/detect"));
  const animationFrameRef = useRef<number | null>(null);
  
  const [isRunning, setIsRunning] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const [currentEmotion, setCurrentEmotion] = useState<string | null>(null);
  const [confidence, setConfidence] = useState(0);
  const [response, setResponse] = useState("");
  const [speechRate, setSpeechRate] = useState([1]);
  const [volume, setVolume] = useState([1]);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [transcript, setTranscript] = useState("");
  const [useAI, setUseAI] = useState(false);
  const [isAIProcessing, setIsAIProcessing] = useState(false);
  const [conversationHistory, setConversationHistory] = useState<Array<{ role: "user" | "assistant"; content: string }>>([]);
  const [wsConnected, setWsConnected] = useState(false);
  const [detectionBoxes, setDetectionBoxes] = useState<Detection[]>([]);
  const [isWaitingForResponse, setIsWaitingForResponse] = useState(false);
  const [lastEmotionTime, setLastEmotionTime] = useState(0);

  // 获取用户设置
  const { data: userSettings } = trpc.emotion.getUserSettings.useQuery(undefined, {
    enabled: !!user,
  });

  // 保存检测历史
  const saveHistory = trpc.emotion.saveDetectionHistory.useMutation();

  // AI智能对话
  const generateAIResponse = trpc.emotion.generateAIResponse.useMutation();

  // 初始化WebSocket连接
  useEffect(() => {
    const client = detectionClientRef.current;

    client.onConnect(() => {
      console.log("✅ WebSocket已连接");
      setWsConnected(true);
    });

    client.onDisconnect(() => {
      console.log("❌ WebSocket已断开");
      setWsConnected(false);
    });

    client.onError((error) => {
      console.error("WebSocket错误:", error);
    });

    client.onMessage((result) => {
      if (result.detections && result.detections.length > 0) {
        const detection = result.detections[0];
        setDetectionBoxes(result.detections);
        
        // 更新表情和置信度
        const emotion = detection.emotion as keyof typeof EMOTIONS;
        if (emotion in EMOTIONS) {
          setCurrentEmotion(emotion);
          setConfidence(detection.confidence);

          // 避免频繁触发回应（至少间隔2秒）
          const now = Date.now();
          if (now - lastEmotionTime > 2000 && !isWaitingForResponse) {
            setLastEmotionTime(now);
            setIsWaitingForResponse(true);

            // 生成回应
            if (useAI) {
              setIsAIProcessing(true);
              generateAIResponse.mutate(
                {
                  userMessage: transcript || "你好",
                  emotion: emotion,
                  conversationHistory,
                },
                {
                  onSuccess: (data) => {
                    setResponse(data.response);
                    setConversationHistory([
                      ...conversationHistory,
                      { role: "user", content: transcript || "你好" },
                      { role: "assistant", content: data.response },
                    ]);
                    setIsAIProcessing(false);
                    setTimeout(() => {
                      handleSpeak(data.response);
                    }, 500);
                  },
                  onError: () => {
                    setIsAIProcessing(false);
                  },
                }
              );
            } else {
              const responses = DEFAULT_RESPONSES[emotion];
              const selectedResponse = responses[Math.floor(Math.random() * responses.length)];
              setResponse(selectedResponse);

              if (user) {
                saveHistory.mutate({
                  emotion: emotion,
                  confidence: detection.confidence,
                  response: selectedResponse,
                });
              }

              setTimeout(() => {
                handleSpeak(selectedResponse);
              }, 500);
            }
          }
        }
      }
    });

    return () => {
      client.disconnect();
    };
  }, [useAI, conversationHistory, isWaitingForResponse, lastEmotionTime, transcript, user]);

  // 初始化摄像头
  useEffect(() => {
    if (!isRunning) return;

    const initCamera = async () => {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({
          video: { width: { ideal: 1280 }, height: { ideal: 720 } },
          audio: false,
        });

        if (videoRef.current) {
          videoRef.current.srcObject = stream;
        }

        // 连接WebSocket
        if (!wsConnected) {
          try {
            await detectionClientRef.current.connect();
          } catch (error) {
            console.error("WebSocket连接失败:", error);
          }
        }
      } catch (error) {
        console.error("无法访问摄像头:", error);
        alert("请允许访问摄像头以使用此功能");
        setIsRunning(false);
      }
    };

    initCamera();

    return () => {
      if (videoRef.current?.srcObject) {
        const tracks = (videoRef.current.srcObject as MediaStream).getTracks();
        tracks.forEach((track) => track.stop());
      }
    };
  }, [isRunning, wsConnected]);

  // 实时发送视频帧到后端
  useEffect(() => {
    if (!isRunning || !wsConnected || !videoRef.current || !canvasRef.current) return;

    const sendFrame = async () => {
      const video = videoRef.current;
      const canvas = canvasRef.current;

      if (video && canvas && video.readyState === video.HAVE_ENOUGH_DATA) {
        canvas.width = video.videoWidth;
        canvas.height = video.videoHeight;
        const ctx = canvas.getContext("2d");
        if (ctx) {
          ctx.drawImage(video, 0, 0);

          try {
            await detectionClientRef.current.sendFrame(canvas);
          } catch (error) {
            console.error("发送帧失败:", error);
          }
        }
      }

      animationFrameRef.current = requestAnimationFrame(sendFrame);
    };

    animationFrameRef.current = requestAnimationFrame(sendFrame);

    return () => {
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current);
      }
    };
  }, [isRunning, wsConnected]);

  // 绘制检测结果
  useEffect(() => {
    const canvas = canvasRef.current;
    const video = videoRef.current;
    if (!canvas || !video) return;

    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    // 清空画布
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    // 绘制检测框
    detectionBoxes.forEach((detection) => {
      const box = detection.box;
      const emotion = detection.emotion as keyof typeof EMOTIONS;
      const emotionData = EMOTIONS[emotion] || EMOTIONS.neutral;

      // 绘制边界框
      ctx.strokeStyle = emotionData.boxColor;
      ctx.lineWidth = 3;
      ctx.strokeRect(box.x, box.y, box.width, box.height);

      // 绘制标签背景
      const label = emotionData.label;
      const fontSize = 16;
      ctx.font = `bold ${fontSize}px Arial`;
      const textMetrics = ctx.measureText(label);
      const textWidth = textMetrics.width + 10;
      const textHeight = fontSize + 8;

      ctx.fillStyle = emotionData.boxColor;
      ctx.fillRect(box.x, box.y - textHeight - 5, textWidth, textHeight);

      // 绘制标签文字
      ctx.fillStyle = "#FFFFFF";
      ctx.fillText(label, box.x + 5, box.y - 8);

      // 绘制置信度
      const confidenceText = `${(detection.confidence * 100).toFixed(1)}%`;
      ctx.fillStyle = "#FFFFFF";
      ctx.font = `${fontSize - 4}px Arial`;
      ctx.fillText(confidenceText, box.x + 5, box.y + box.height + 20);
    });
  }, [detectionBoxes]);

  // 初始化语音识别
  useEffect(() => {
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRecognition) {
      console.warn("浏览器不支持语音识别");
      return;
    }

    const recognition = new SpeechRecognition();
    recognition.lang = "zh-CN";
    recognition.continuous = true;
    recognition.interimResults = true;

    recognition.onstart = () => {
      setIsListening(true);
      setTranscript("");
    };

    recognition.onresult = (event: any) => {
      let interimTranscript = "";
      for (let i = event.resultIndex; i < event.results.length; i++) {
        const transcript = event.results[i][0].transcript;
        if (event.results[i].isFinal) {
          setTranscript(transcript);
          setIsWaitingForResponse(false);
        } else {
          interimTranscript += transcript;
        }
      }
      if (interimTranscript) {
        setTranscript(interimTranscript);
      }
    };

    recognition.onerror = (event: any) => {
      console.error("语音识别错误:", event.error);
      setIsListening(false);
    };

    recognition.onend = () => {
      setIsListening(false);
    };

    recognitionRef.current = recognition;

    return () => {
      if (recognitionRef.current) {
        recognitionRef.current.stop();
      }
    };
  }, []);

  // 启动/停止语音识别
  const toggleSpeechRecognition = () => {
    if (!recognitionRef.current) {
      alert("您的浏览器不支持语音识别功能");
      return;
    }

    if (isListening) {
      recognitionRef.current.stop();
      setIsListening(false);
    } else {
      recognitionRef.current.start();
    }
  };

  // 播放语音
  const handleSpeak = (text: string = response) => {
    if (!text) return;

    setIsSpeaking(true);
    try {
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.rate = speechRate[0];
      utterance.volume = volume[0];
      utterance.lang = "zh-CN";

      utterance.onend = () => {
        setIsSpeaking(false);
      };

      window.speechSynthesis.cancel();
      window.speechSynthesis.speak(utterance);
    } catch (error) {
      console.error("语音合成失败:", error);
      setIsSpeaking(false);
    }
  };

  const handleLogout = async () => {
    await logout();
    setLocation("/");
  };

  const emotionData = currentEmotion ? EMOTIONS[currentEmotion as keyof typeof EMOTIONS] : null;

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-white">
      {/* Header */}
      <header className="sticky top-0 z-50 bg-white border-b border-blue-100">
        <div className="container max-w-6xl mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-10 h-10 bg-gradient-to-br from-blue-600 to-blue-700 rounded-lg flex items-center justify-center">
              <span className="text-white font-bold">AI</span>
            </div>
            <span className="text-xl font-bold text-gray-900">情感交互应用</span>
            <div className={`flex items-center gap-1 px-3 py-1 rounded-full text-xs font-semibold ${
              wsConnected ? "bg-green-100 text-green-700" : "bg-red-100 text-red-700"
            }`}>
              {wsConnected ? (
                <>
                  <Wifi className="w-3 h-3" /> 已连接
                </>
              ) : (
                <>
                  <WifiOff className="w-3 h-3" /> 未连接
                </>
              )}
            </div>
          </div>
          <div className="flex items-center gap-4">
            <span className="text-sm text-gray-600">{user?.name}</span>
            <Button
              onClick={handleLogout}
              variant="outline"
              size="sm"
              className="gap-2"
            >
              <LogOut className="w-4 h-4" /> 退出
            </Button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container max-w-6xl mx-auto px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Camera Section */}
          <div className="lg:col-span-2 space-y-6">
            {/* Video Feed with Detection Box */}
            <Card className="border-blue-200 overflow-hidden">
              <CardHeader>
                <CardTitle>摄像头视频流 (YOLOv11实时检测)</CardTitle>
                <CardDescription>实时表情检测和语音识别</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="relative bg-black rounded-lg overflow-hidden aspect-video">
                  <video
                    ref={videoRef}
                    autoPlay
                    playsInline
                    muted
                    className="w-full h-full object-cover"
                  />
                  {/* Detection Canvas Overlay */}
                  <canvas
                    ref={canvasRef}
                    className="absolute inset-0 w-full h-full"
                  />

                  {/* Status Overlays */}
                  <div className="absolute top-4 left-4 flex gap-2 flex-wrap">
                    <div className={`px-3 py-2 rounded-lg text-sm font-semibold text-white ${
                      isRunning ? "bg-green-500/80" : "bg-red-500/80"
                    }`}>
                      {isRunning ? "🟢 检测中" : "⚫ 已停止"}
                    </div>
                    {isListening && (
                      <div className="px-3 py-2 rounded-lg text-sm font-semibold text-white bg-blue-500/80 animate-pulse">
                        🎤 正在听
                      </div>
                    )}
                    {useAI && (
                      <div className="px-3 py-2 rounded-lg text-sm font-semibold text-white bg-purple-500/80 animate-pulse">
                        ✨ AI模式
                      </div>
                    )}
                    {isWaitingForResponse && (
                      <div className="px-3 py-2 rounded-lg text-sm font-semibold text-white bg-orange-500/80 animate-pulse">
                        ⏳ 等待回复
                      </div>
                    )}
                    {!wsConnected && (
                      <div className="px-3 py-2 rounded-lg text-sm font-semibold text-white bg-red-600/80 animate-pulse">
                        ⚠️ 后端未连接
                      </div>
                    )}
                  </div>

                  {/* Transcript Display */}
                  {transcript && (
                    <div className="absolute bottom-4 left-4 right-4 bg-black/70 text-white px-4 py-2 rounded-lg text-sm">
                      <p className="text-gray-300">您说: <span className="text-white font-semibold">{transcript}</span></p>
                    </div>
                  )}
                </div>

                {/* Controls */}
                <div className="flex gap-4">
                  <Button
                    onClick={() => setIsRunning(!isRunning)}
                    className={`flex-1 gap-2 ${
                      isRunning
                        ? "bg-red-600 hover:bg-red-700"
                        : "bg-blue-600 hover:bg-blue-700"
                    }`}
                  >
                    {isRunning ? (
                      <>
                        <Square className="w-4 h-4" /> 停止检测
                      </>
                    ) : (
                      <>
                        <Play className="w-4 h-4" /> 开始检测
                      </>
                    )}
                  </Button>
                  <Button
                    onClick={toggleSpeechRecognition}
                    disabled={!isRunning}
                    className={`flex-1 gap-2 ${
                      isListening
                        ? "bg-blue-600 hover:bg-blue-700"
                        : "bg-gray-600 hover:bg-gray-700"
                    }`}
                  >
                    <Mic className="w-4 h-4" /> {isListening ? "停止听" : "开始听"}
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* Detection Result */}
            {emotionData && (
              <Card className={`border-blue-200 ${emotionData.color}`}>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <span className="text-3xl">{emotionData.emoji}</span>
                    <span className={emotionData.textColor}>{emotionData.label}</span>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-gray-700">置信度</span>
                      <span className="font-semibold text-blue-600">
                        {(confidence * 100).toFixed(1)}%
                      </span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2">
                      <div
                        className="bg-gradient-to-r from-blue-500 to-blue-600 h-2 rounded-full transition-all"
                        style={{ width: `${confidence * 100}%` }}
                      ></div>
                    </div>
                  </div>
                  {isWaitingForResponse && (
                    <div className="text-sm text-gray-600 italic">
                      ⏳ 等待您的回复...
                    </div>
                  )}
                </CardContent>
              </Card>
            )}
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* AI Mode Toggle */}
            <Card className="border-purple-200 bg-gradient-to-br from-purple-50 to-white">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-base">
                  <Sparkles className="w-4 h-4 text-purple-600" />
                  AI智能模式
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <Button
                  onClick={() => setUseAI(!useAI)}
                  className={`w-full gap-2 ${
                    useAI
                      ? "bg-purple-600 hover:bg-purple-700"
                      : "bg-gray-400 hover:bg-gray-500"
                  }`}
                >
                  <Sparkles className="w-4 h-4" />
                  {useAI ? "✨ AI模式已启用" : "启用AI智能回应"}
                </Button>
                <p className="text-xs text-gray-600">
                  {useAI 
                    ? "AI将根据您的表情和语音内容生成个性化的智能回应"
                    : "启用此功能以获得AI驱动的个性化回应"}
                </p>
              </CardContent>
            </Card>

            {/* Response Card */}
            {response && (
              <Card className={`border-green-200 bg-gradient-to-br ${useAI ? "from-purple-50" : "from-green-50"} to-white`}>
                <CardHeader>
                  <CardTitle className="text-base flex items-center gap-2">
                    {useAI && <Sparkles className="w-4 h-4 text-purple-600" />}
                    系统回应
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-700 leading-relaxed italic">"{response}"</p>
                </CardContent>
              </Card>
            )}

            {/* Voice Settings */}
            <Card className="border-purple-200">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-base">
                  <Volume2 className="w-4 h-4 text-purple-600" />
                  语音设置
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Speech Rate */}
                <div className="space-y-2">
                  <label className="text-sm font-medium text-gray-700">语速</label>
                  <Slider
                    value={speechRate}
                    onValueChange={setSpeechRate}
                    min={0.5}
                    max={2}
                    step={0.1}
                  />
                  <div className="flex justify-between text-xs text-gray-500">
                    <span>0.5x</span>
                    <span>1.0x</span>
                    <span>2.0x</span>
                  </div>
                </div>

                {/* Volume */}
                <div className="space-y-2">
                  <label className="text-sm font-medium text-gray-700">音量</label>
                  <Slider
                    value={volume}
                    onValueChange={setVolume}
                    min={0}
                    max={1}
                    step={0.1}
                  />
                  <div className="flex justify-between text-xs text-gray-500">
                    <span>静音</span>
                    <span>正常</span>
                    <span>最大</span>
                  </div>
                </div>

                {/* Speak Button */}
                <Button
                  onClick={() => handleSpeak()}
                  disabled={!response || isSpeaking || isAIProcessing}
                  className="w-full bg-purple-600 hover:bg-purple-700 text-white gap-2"
                >
                  <Volume2 className="w-4 h-4" />
                  {isSpeaking ? "正在播放..." : isAIProcessing ? "AI生成中..." : "播放语音"}
                </Button>
              </CardContent>
            </Card>

            {/* Quick Actions */}
            <div className="flex flex-col gap-2">
              <Button
                onClick={() => setLocation("/settings")}
                variant="outline"
                className="gap-2"
              >
                <Settings className="w-4 h-4" /> 设置
              </Button>
              <Button
                onClick={() => setLocation("/history")}
                variant="outline"
                className="gap-2"
              >
                <History className="w-4 h-4" /> 历史记录
              </Button>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
