import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Slider } from "@/components/ui/slider";
import { Volume2, Zap, MessageCircle, Smile } from "lucide-react";

const EMOTIONS = [
  { id: "happy", label: "开心", color: "bg-yellow-100", emoji: "😊", textColor: "text-yellow-600" },
  { id: "sad", label: "悲伤", color: "bg-blue-100", emoji: "😢", textColor: "text-blue-600" },
  { id: "angry", label: "生气", color: "bg-red-100", emoji: "😠", textColor: "text-red-600" },
  { id: "fearful", label: "恐惧", color: "bg-purple-100", emoji: "😨", textColor: "text-purple-600" },
  { id: "neutral", label: "平静", color: "bg-gray-100", emoji: "😐", textColor: "text-gray-600" },
];

const RESPONSES = {
  happy: [
    "看到你这么开心，我也很高兴！",
    "你的笑容真灿烂！",
    "很高兴看到你这么开心！",
  ],
  sad: [
    "别难过，一切都会好起来的。",
    "我在这里陪着你。",
    "希望你很快就会感到好一些。",
  ],
  angry: [
    "深呼吸，冷静一下。",
    "我理解你的感受。",
    "让我们一起解决这个问题。",
  ],
  fearful: [
    "不用害怕，我在这里。",
    "你很勇敢，你可以做到。",
    "一切都会没事的。",
  ],
  neutral: [
    "你好，有什么我可以帮助的吗？",
    "今天过得怎么样？",
    "很高兴见到你。",
  ],
};

export default function EmotionDemo() {
  const [selectedEmotion, setSelectedEmotion] = useState<string>("happy");
  const [response, setResponse] = useState<string>("");
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [speechRate, setSpeechRate] = useState([1]);
  const [volume, setVolume] = useState([1]);
  const [confidence, setConfidence] = useState(0);

  const handleEmotionSelect = (emotionId: string) => {
    setSelectedEmotion(emotionId);
    // 生成随机置信度
    setConfidence(Math.random() * 0.3 + 0.7); // 70-100%
    // 获取随机回应
    const emotionResponses = RESPONSES[emotionId as keyof typeof RESPONSES] || [];
    const randomResponse = emotionResponses[Math.floor(Math.random() * emotionResponses.length)];
    setResponse(randomResponse);
  };

  const handleSpeak = async () => {
    if (!response) return;

    setIsSpeaking(true);
    try {
      // 使用Web Speech API进行语音合成
      const utterance = new SpeechSynthesisUtterance(response);
      utterance.rate = speechRate[0];
      utterance.volume = volume[0];
      utterance.lang = "zh-CN";

      utterance.onend = () => {
        setIsSpeaking(false);
      };

      window.speechSynthesis.cancel();
      window.speechSynthesis.speak(utterance);
    } catch (error) {
      console.error("语音合成失败:", error);
      setIsSpeaking(false);
    }
  };

  const currentEmotion = EMOTIONS.find((e) => e.id === selectedEmotion);

  return (
    <div className="space-y-8">
      {/* Emotion Selection */}
      <div>
        <h3 className="text-lg font-semibold text-gray-900 mb-4">选择表情</h3>
        <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
          {EMOTIONS.map((emotion) => (
            <button
              key={emotion.id}
              onClick={() => handleEmotionSelect(emotion.id)}
              className={`p-4 rounded-lg transition-all ${
                selectedEmotion === emotion.id
                  ? `${emotion.color} ring-2 ring-offset-2 ring-blue-600 scale-105`
                  : `${emotion.color} hover:shadow-md`
              }`}
            >
              <div className="text-3xl mb-2">{emotion.emoji}</div>
              <div className="text-sm font-medium text-gray-700">{emotion.label}</div>
            </button>
          ))}
        </div>
      </div>

      {/* Detection Result */}
      {currentEmotion && (
        <Card className="border-blue-200 bg-gradient-to-br from-blue-50 to-white">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Zap className="w-5 h-5 text-blue-600" />
              检测结果
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-gray-700 font-medium">识别表情：</span>
              <span className={`text-lg font-bold ${currentEmotion.textColor}`}>
                {currentEmotion.label}
              </span>
            </div>
            <div className="space-y-2">
              <div className="flex items-center justify-between text-sm">
                <span className="text-gray-600">置信度</span>
                <span className="font-semibold text-blue-600">{(confidence * 100).toFixed(1)}%</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div
                  className="bg-gradient-to-r from-blue-500 to-blue-600 h-2 rounded-full transition-all duration-500"
                  style={{ width: `${confidence * 100}%` }}
                ></div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Response Text */}
      {response && (
        <Card className="border-green-200 bg-gradient-to-br from-green-50 to-white">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <MessageCircle className="w-5 h-5 text-green-600" />
              系统回应
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-gray-700 leading-relaxed italic">"{response}"</p>
          </CardContent>
        </Card>
      )}

      {/* Voice Settings */}
      <Card className="border-purple-200">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Volume2 className="w-5 h-5 text-purple-600" />
            语音设置
          </CardTitle>
          <CardDescription>调整语速和音量</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Speech Rate */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <label className="text-sm font-medium text-gray-700">语速</label>
              <span className="text-sm text-gray-600">
                {speechRate[0] < 1 ? "慢" : speechRate[0] === 1 ? "正常" : "快"}
              </span>
            </div>
            <Slider
              value={speechRate}
              onValueChange={setSpeechRate}
              min={0.5}
              max={2}
              step={0.1}
              className="w-full"
            />
            <div className="flex justify-between text-xs text-gray-500">
              <span>0.5x</span>
              <span>1.0x</span>
              <span>2.0x</span>
            </div>
          </div>

          {/* Volume */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <label className="text-sm font-medium text-gray-700">音量</label>
              <span className="text-sm text-gray-600">{(volume[0] * 100).toFixed(0)}%</span>
            </div>
            <Slider
              value={volume}
              onValueChange={setVolume}
              min={0}
              max={1}
              step={0.1}
              className="w-full"
            />
            <div className="flex justify-between text-xs text-gray-500">
              <span>静音</span>
              <span>正常</span>
              <span>最大</span>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Action Button */}
      <div className="flex gap-4">
        <Button
          onClick={handleSpeak}
          disabled={!response || isSpeaking}
          className="flex-1 bg-blue-600 hover:bg-blue-700 text-white gap-2 py-6 text-base"
        >
          <Volume2 className="w-5 h-5" />
          {isSpeaking ? "正在播放..." : "播放语音"}
        </Button>
        <Button
          onClick={() => {
            window.speechSynthesis.cancel();
            setIsSpeaking(false);
          }}
          disabled={!isSpeaking}
          variant="outline"
          className="px-6 py-6"
        >
          停止
        </Button>
      </div>

      {/* Info Box */}
      <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
        <p className="text-sm text-gray-700">
          <span className="font-semibold text-blue-600">💡 提示：</span>
          这是一个交互式演示。在实际应用中，系统会通过摄像头实时检测您的面部表情，自动生成回应并播放语音。
        </p>
      </div>
    </div>
  );
}
